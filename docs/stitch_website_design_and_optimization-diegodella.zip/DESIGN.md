---
name: Asphalt & Ivory
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#cfc4c5'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#988e90'
  outline-variant: '#4c4546'
  surface-tint: '#c6c6c6'
  primary: '#c6c6c6'
  on-primary: '#303030'
  primary-container: '#000000'
  on-primary-container: '#757575'
  inverse-primary: '#5e5e5e'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#ffb690'
  on-tertiary: '#552100'
  tertiary-container: '#000000'
  on-tertiary-container: '#c25400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb690'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#783200'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
  signal-orange: '#F97316'
  strobe-white: '#FFFFFF'
  void-black: '#000000'
  industrial-gray: '#262626'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 84px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.1'
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
  mono-label:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.0'
spacing:
  base: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 128px
---

## Brand & Style

This design system embodies an "Urban Underground meets Luxury" aesthetic. It is built for a premium streetwear audience that values exclusivity, grit, and high-fashion editorial standards. The personality is confident, unapologetic, and minimalist, utilizing a **Brutalist-Minimalist** hybrid style.

The visual direction prioritizes high-impact imagery over UI decoration. We use raw, industrial elements—like heavy borders and monospaced accents—to ground the luxury feel in a street-level reality. Expect heavy whitespace to act as a "gallery wall" for product photography, ensuring every item feels like a curated piece of art.

## Colors

The palette is strictly high-contrast to evoke a nocturnal, urban atmosphere. 

- **Primary & Neutral:** Deep, "Void Black" is the foundation for all surfaces. Text is rendered in "Strobe White" to ensure maximum punch.
- **Accent:** "Signal Orange" is used sparingly for critical actions, status indicators, or "limited edition" tags. It represents the industrial hazard lights and neon flickers of an underground environment.
- **Usage:** Maintain a 90% black/white ratio, using the accent color only for 10% of the interface to preserve its impact.

## Typography

Typography functions as a structural element. 

- **Space Grotesk** is our industrial engine. It is used for all headlines and navigation to provide technical grit. Headlines should often be set in tight leading with negative letter-spacing for a "crushed" editorial look.
- **Inter** provides the functional balance. It is used exclusively for body copy, product descriptions, and long-form text to ensure readability against dark backgrounds.
- **Styling Note:** Use `label-caps` for all secondary metadata, categories, and utility links to maintain the "manifesto" feel of the brand.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model. Content is contained within a 1440px max-width wrapper, but background elements and full-bleed imagery should break the container to create a sense of scale.

- **Grid:** Use a 12-column grid for desktop with wide 64px margins. This creates the "gallery" effect where whitespace is as important as the content.
- **Rhythm:** Utilize an 8px base unit. Sections should be separated by aggressive gaps (128px+) to force the user to focus on one product story at a time.
- **Mobile:** Transition to a 4-column grid with 20px margins. Stack content vertically, maintaining high-contrast headers to drive the visual hierarchy.

## Elevation & Depth

This design system rejects soft shadows and "friendly" depth. 

- **Tonal Layers:** Depth is achieved through "Industrial Gray" (#262626) overlays on "Void Black" (#000000) backgrounds. There are no blurs.
- **Sharp Shadows:** If a shadow is required for legibility on imagery, use a hard-edged, 0-blur offset shadow (e.g., 4px 4px 0px #000000) to maintain the brutalist aesthetic.
- **Outlines:** Use 1px "Strobe White" borders for interactive elements like input fields and card containers. This defines the shape without needing traditional elevation.

## Shapes

The shape language is strictly **Sharp (0px)**. 

Every button, card, input field, and image container must have 90-degree corners. This reinforces the architectural and industrial nature of the brand. Soft corners are prohibited as they conflict with the "edgy" grit of the rodeo-inspired identity.

## Components

- **Buttons:** Primary buttons are solid "Strobe White" with "Void Black" Space Grotesk caps. Secondary buttons are 1px white outlines. Hover states should invert the colors instantly (no long transitions).
- **Product Cards:** Cards have no background or borders by default; they rely on full-bleed photography. Text metadata (Price, Name) is placed underneath in `label-caps`.
- **Input Fields:** 1px white bottom-border only, mimicking high-end stationery or technical blueprints. Label text should be small and uppercase.
- **Chips/Tags:** Used for "Sold Out" or "New Drop." Rectangular boxes with "Signal Orange" backgrounds and black text.
- **Lists:** Clean, horizontal rules (1px) separating items. Use monospaced numbering (e.g., 01, 02) to add to the technical, "catalog" feel.
- **Navigation:** A minimalist top-bar. Use `label-caps` for links. On scroll, the navigation should have a solid black background with no transparency.